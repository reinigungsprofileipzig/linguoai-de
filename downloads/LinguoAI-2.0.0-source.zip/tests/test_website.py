import json
import unittest
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).resolve().parents[1]
WEBSITE = ROOT / "website"


class _WebsiteParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.ids: set[str] = set()
        self.references: list[tuple[str, str, str]] = []
        self.h1_count = 0
        self.html_language = ""
        self.external_runtime_resources: list[str] = []
        self._json_ld_depth = 0
        self._json_ld_parts: list[str] = []
        self.json_ld: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        if tag == "html":
            self.html_language = values.get("lang", "") or ""
        if tag == "h1":
            self.h1_count += 1
        if identifier := values.get("id"):
            self.ids.add(identifier)

        attribute = "href" if tag in {"a", "link"} else "src" if tag in {"img", "script"} else ""
        if attribute and (reference := values.get(attribute)):
            self.references.append((tag, attribute, reference))
            is_runtime_resource = tag in {"img", "script"} or (
                tag == "link" and values.get("rel") in {"stylesheet", "icon", "manifest", "preload"}
            )
            if is_runtime_resource and reference.startswith(("http://", "https://")):
                self.external_runtime_resources.append(reference)

        if tag == "script" and values.get("type") == "application/ld+json":
            self._json_ld_depth = 1
            self._json_ld_parts = []

    def handle_endtag(self, tag: str) -> None:
        if tag == "script" and self._json_ld_depth:
            self.json_ld.append("".join(self._json_ld_parts))
            self._json_ld_depth = 0
            self._json_ld_parts = []

    def handle_data(self, data: str) -> None:
        if self._json_ld_depth:
            self._json_ld_parts.append(data)


def _parse(path: Path) -> _WebsiteParser:
    parser = _WebsiteParser()
    parser.feed(path.read_text(encoding="utf-8"))
    return parser


class WebsiteTests(unittest.TestCase):
    def test_required_static_site_files_exist(self) -> None:
        expected = (
            "index.html",
            "404.html",
            "impressum.html",
            "datenschutz.html",
            "robots.txt",
            "sitemap.xml",
            "site.webmanifest",
            "_headers",
            "assets/styles.css",
            "assets/site.js",
            "assets/favicon.svg",
            "assets/logo-mark.svg",
            "downloads/LinguoAI_Colab.ipynb",
        )
        for relative in expected:
            with self.subTest(relative=relative):
                self.assertTrue((WEBSITE / relative).is_file())

    def test_every_html_page_is_german_and_has_one_h1(self) -> None:
        for page in WEBSITE.glob("*.html"):
            with self.subTest(page=page.name):
                parser = _parse(page)
                self.assertEqual(parser.html_language, "de")
                self.assertEqual(parser.h1_count, 1)

    def test_internal_files_and_home_fragments_resolve(self) -> None:
        parsed_pages = {page.resolve(): _parse(page) for page in WEBSITE.glob("*.html")}
        for page, parser in parsed_pages.items():
            for tag, attribute, reference in parser.references:
                with self.subTest(page=page.name, reference=reference):
                    parts = urlsplit(reference)
                    if parts.scheme or reference.startswith(("mailto:", "tel:")):
                        continue
                    if not parts.path:
                        if parts.fragment:
                            self.assertIn(parts.fragment, parser.ids)
                        continue
                    if parts.path.startswith("/"):
                        target = WEBSITE / unquote(parts.path.lstrip("/"))
                    else:
                        target = page.parent / unquote(parts.path)
                    if parts.path.endswith("/"):
                        target /= "index.html"
                    self.assertTrue(target.resolve().is_file(), f"{tag}[{attribute}] -> {target}")
                    if parts.fragment and target.suffix.casefold() == ".html":
                        target_parser = parsed_pages.get(target.resolve()) or _parse(target)
                        self.assertIn(parts.fragment, target_parser.ids)

    def test_homepage_uses_no_external_runtime_assets(self) -> None:
        parser = _parse(WEBSITE / "index.html")
        self.assertEqual(parser.external_runtime_resources, [])

    def test_homepage_structured_data_is_valid_json(self) -> None:
        parser = _parse(WEBSITE / "index.html")
        self.assertEqual(len(parser.json_ld), 1)
        data = json.loads(parser.json_ld[0])
        types = {item["@type"] for item in data["@graph"]}
        self.assertEqual(types, {"WebSite", "SoftwareApplication", "FAQPage"})

    def test_legal_placeholders_do_not_leak_into_homepage(self) -> None:
        homepage = (WEBSITE / "index.html").read_text(encoding="utf-8")
        self.assertNotIn('class="placeholder"', homepage)
        self.assertNotIn("BITTE ERGÄNZEN", homepage)

    def test_colab_download_matches_current_notebook(self) -> None:
        source = ROOT / "notebooks" / "LinguoAI_Colab.ipynb"
        download = WEBSITE / "downloads" / "LinguoAI_Colab.ipynb"
        self.assertEqual(download.read_bytes(), source.read_bytes())


if __name__ == "__main__":
    unittest.main()
