import threading
import unittest

from linguoai.config import AppConfig
from linguoai.domain import Segment
from linguoai.errors import TranslationError
from linguoai.translation import (
    GOOGLE_TARGET_LANGUAGE_ALIASES,
    DeepTranslatorAdapter,
    GeminiStructuredClient,
    TranslationManager,
)


class FakeAdapter:
    def __init__(self, name: str, *, error: Exception | None = None, prefix: str = "") -> None:
        self.name = name
        self.error = error
        self.prefix = prefix
        self.calls = 0

    def translate_batch(self, texts, *, source_language, target_language, cancel_event=None):
        self.calls += 1
        if self.error:
            raise self.error
        return [self.prefix + text for text in texts]

    def close(self) -> None:
        return


class TranslationTests(unittest.TestCase):
    def test_only_selected_provider_is_called(self) -> None:
        google = FakeAdapter("google", prefix="DE: ")
        hidden = FakeAdapter("gemini", prefix="G: ")
        manager = TranslationManager(
            AppConfig(request_retries=1),
            adapters={"google": google, "gemini": hidden},
        )
        result = manager.translate_segments(
            [Segment(0.0, 1.0, "Hello")],
            source_language="en",
            cancel_event=threading.Event(),
        )
        self.assertEqual(result[0].text, "DE: Hello")
        self.assertEqual(google.calls, 1)
        self.assertEqual(hidden.calls, 0)

    def test_explicit_fallback_is_used_after_failure(self) -> None:
        primary = FakeAdapter("google", error=RuntimeError("offline"))
        fallback = FakeAdapter("gemini", prefix="DE: ")
        config = AppConfig(
            fallback_services=("gemini",),
            gemini_api_key="test-key",
            request_retries=1,
        )
        manager = TranslationManager(
            config,
            adapters={"google": primary, "gemini": fallback},
        )
        result = manager.translate_segments(
            [Segment(0.0, 1.0, "Hello")],
            source_language="en",
            cancel_event=threading.Event(),
        )
        self.assertEqual(result[0].text, "DE: Hello")
        self.assertEqual(primary.calls, 1)
        self.assertEqual(fallback.calls, 1)

    def test_provider_errors_redact_api_keys(self) -> None:
        secret = "very-secret-key"
        adapter = FakeAdapter(
            "deepl",
            error=RuntimeError(f"request failed: auth_key={secret}"),
        )
        logs: list[str] = []
        manager = TranslationManager(
            AppConfig(
                translation_service="deepl",
                deepl_api_key=secret,
                request_retries=1,
            ),
            adapters={"deepl": adapter},
            logger=logs.append,
        )
        with self.assertRaises(TranslationError) as caught:
            manager.translate_segments(
                [Segment(0.0, 1.0, "private cue")],
                source_language="en",
                cancel_event=threading.Event(),
            )
        combined = f"{caught.exception} {' '.join(logs)}"
        self.assertNotIn(secret, combined)
        self.assertIn("[REDACTED]", combined)

    def test_deepl_retries_server_errors(self) -> None:
        error = RuntimeError("server")
        error.http_status_code = 502
        self.assertTrue(DeepTranslatorAdapter("deepl").is_retryable(error))

    def test_gemini_retries_connect_errors(self) -> None:
        ConnectError = type("ConnectError", (RuntimeError,), {})
        self.assertTrue(GeminiStructuredClient.is_retryable(ConnectError()))

    def test_google_uses_legacy_hebrew_target_code(self) -> None:
        self.assertEqual(GOOGLE_TARGET_LANGUAGE_ALIASES["he"], "iw")


if __name__ == "__main__":
    unittest.main()
