import ast
import json
import tempfile
import threading
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest import mock

from linguoai.colab_ui import (
    _copy_file_cancellable,
    process_colab_job,
    resolve_drive_output_directory,
    resolve_input_video,
    resolve_optional_job_file,
)
from linguoai.domain import BatchResult, JobResult
from linguoai.errors import CancelledError


class ColabTests(unittest.TestCase):
    def test_drive_input_is_confined_to_my_drive(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "MyDrive"
            video = root / "Videos" / "demo.mp4"
            video.parent.mkdir(parents=True)
            video.write_bytes(b"video")
            self.assertEqual(
                resolve_input_video(None, "Videos/demo.mp4", drive_root=root),
                video.resolve(),
            )
            with self.assertRaisesRegex(ValueError, "MyDrive"):
                resolve_input_video(None, "../secret.mp4", drive_root=root)

    def test_upload_takes_precedence_over_drive_text(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            video = Path(temporary) / "upload.mkv"
            video.write_bytes(b"video")
            self.assertEqual(
                resolve_input_video(str(video), "../ignored.mp4"),
                video.resolve(),
            )

    def test_drive_output_rejects_parent_traversal(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "MyDrive"
            root.mkdir()
            with self.assertRaises(ValueError):
                resolve_drive_output_directory("../outside", drive_root=root)

    def test_optional_tts_file_is_confined_to_my_drive(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "MyDrive"
            reference = root / "Voices" / "reference.wav"
            reference.parent.mkdir(parents=True)
            reference.write_bytes(b"wave")
            self.assertEqual(
                resolve_optional_job_file(
                    None,
                    "Voices/reference.wav",
                    label="Stimmreferenz",
                    allowed_extensions=frozenset({".wav"}),
                    required=True,
                    drive_root=root,
                ),
                reference.resolve(),
            )
            with self.assertRaisesRegex(ValueError, "MyDrive"):
                resolve_optional_job_file(
                    None,
                    "../reference.wav",
                    label="Stimmreferenz",
                    allowed_extensions=frozenset({".wav"}),
                    required=True,
                    drive_root=root,
                )

    def test_optional_tts_upload_takes_precedence_and_checks_format(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            uploaded = Path(temporary) / "voice.onnx"
            uploaded.write_bytes(b"onnx")
            self.assertEqual(
                resolve_optional_job_file(
                    str(uploaded),
                    "../ignored.onnx",
                    label="Piper-Modell",
                    allowed_extensions=frozenset({".onnx"}),
                    required=True,
                ),
                uploaded.resolve(),
            )
            with self.assertRaisesRegex(ValueError, "Dateiformat"):
                resolve_optional_job_file(
                    str(uploaded),
                    "",
                    label="JSON",
                    allowed_extensions=frozenset({".json"}),
                )

    def test_piper_assets_are_copied_into_isolated_job(self) -> None:
        class FakeColabPipeline:
            checked_job_directory = False
            last_config = None

            def __init__(self, config, *, event_sink, cancel_event):
                type(self).last_config = config.validated()

            def run_path(self, source, output):
                config = type(self).last_config
                type(self).checked_job_directory = (
                    config.piper_model.parent == Path(source).parent
                    and config.piper_config.parent == Path(source).parent
                    and config.piper_model.name == "piper-model.onnx"
                    and config.piper_config.name == "piper-model.onnx.json"
                )
                output.write_bytes(b"video")
                original = output.with_suffix(".original.srt")
                translated = output.with_suffix(".translated.srt")
                original.write_text("original", encoding="utf-8")
                translated.write_text("translated", encoding="utf-8")
                completed = JobResult(
                    input_path=Path(source),
                    output_path=Path(output),
                    original_subtitles=original,
                    translated_subtitles=translated,
                    source_language="en",
                    segment_count=1,
                )
                return BatchResult(completed=(completed,))

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            video = root / "video.mp4"
            model = root / "voice.onnx"
            model_config = root / "voice.onnx.json"
            video.write_bytes(b"video")
            model.write_bytes(b"onnx")
            model_config.write_text("{}", encoding="utf-8")
            with (
                mock.patch("linguoai.colab_ui.COLAB_ROOT", root),
                mock.patch("linguoai.colab_ui.JOB_ROOT", root / "jobs"),
                mock.patch("linguoai.colab_ui.OUTPUT_ROOT", root / "outputs"),
                mock.patch("linguoai.colab_ui.VideoDubbingPipeline", FakeColabPipeline),
                mock.patch("linguoai.colab_ui._schedule_output_cleanup"),
                mock.patch(
                    "linguoai.colab_ui.shutil.disk_usage",
                    return_value=SimpleNamespace(free=10 * 1024**3),
                ),
            ):
                status, downloads = process_colab_job(
                    uploaded_video=str(video),
                    drive_path="",
                    target_language="de",
                    source_language="auto",
                    translation_service="google",
                    whisper_model="tiny",
                    device="cpu",
                    nllb_device="cpu",
                    nllb_model="facebook/nllb-200-distilled-600M",
                    nllb_revision="",
                    nllb_batch_size=1,
                    nllb_source_code="",
                    nllb_target_code="",
                    tts_voice="",
                    deepl_api_key="",
                    gemini_api_key="",
                    optimize_transcript=False,
                    save_to_drive=False,
                    drive_output_folder="",
                    tts_engine="piper",
                    tts_device="cpu",
                    uploaded_piper_model=str(model),
                    uploaded_piper_config=str(model_config),
                )
            self.assertIn("Fertig mit piper", status)
            self.assertEqual(len(downloads), 3)
            self.assertTrue(FakeColabPipeline.checked_job_directory)

    def test_notebook_is_valid_and_has_no_stored_outputs(self) -> None:
        path = Path(__file__).resolve().parents[1] / "notebooks" / "LinguoAI_Colab.ipynb"
        notebook = json.loads(path.read_text(encoding="utf-8"))
        self.assertEqual(notebook["nbformat"], 4)
        for cell in notebook["cells"]:
            if cell["cell_type"] == "code":
                ast.parse("".join(cell["source"]))
                self.assertIsNone(cell["execution_count"])
                self.assertEqual(cell["outputs"], [])
        sources = "\n".join("".join(cell["source"]) for cell in notebook["cells"])
        self.assertIn("LOCAL_TTS_EXTRA", sources)

    def test_large_file_copy_honors_cancellation_and_removes_partial(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "source.mp4"
            destination = root / "destination.mp4"
            source.write_bytes(b"video")
            cancel_event = threading.Event()
            cancel_event.set()
            with self.assertRaises(CancelledError):
                _copy_file_cancellable(source, destination, cancel_event)
            self.assertFalse(destination.exists())


if __name__ == "__main__":
    unittest.main()
