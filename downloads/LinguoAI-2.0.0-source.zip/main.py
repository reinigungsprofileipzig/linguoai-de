"""Kompatibler Startpunkt fuer direkte Aufrufe mit ``python main.py``."""

from linguoai.cli import entrypoint

if __name__ == "__main__":
    entrypoint()
