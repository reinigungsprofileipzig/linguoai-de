# Änderungsprotokoll

## 2.1.0

- Gesamttranskript als Übersetzungskontext für Gemini und unterstützte DeepL-SDKs.
- Adaptive Nutzung freier Pausen vor und nach Sprachsegmenten.
- Zeitliche Neuverteilung kleiner benachbarter Segmentgruppen.
- Automatisches Zusammenfassen überlanger Nachbar-Cues vor starker Beschleunigung.
- Optionale inhaltstreue Kürzung problematischer Zieltexte mit Gemini und erneute TTS-Prüfung.
- Bevorzugtes Tempo 1,35x; Notfall-Maximum standardmäßig 2,20x.
- Neue Tests für Kontextübergabe und adaptive Zeitplanung.
